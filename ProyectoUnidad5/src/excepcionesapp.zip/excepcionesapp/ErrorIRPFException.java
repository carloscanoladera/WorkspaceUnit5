package excepcionesapp;

public class ErrorIRPFException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	
	public ErrorIRPFException() {
		
		
		super("Error de IRPF en el empleado. Demasiado alto. Solucionar");
	
				
	}
	
	
	
	
}
